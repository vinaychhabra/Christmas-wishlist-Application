<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\WishlistItem;

class WishlistController extends Controller
{
    public function addItem(Request $request)
    {
        // Validate the request data
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        // Create a new wishlist item
        $wishlistItem = WishlistItem::create([
            'user_id' => auth()->user()->id,
            'title' => $request->title,
            'description' => $request->description,
            'bought' => false,
        ]);

        // Redirect to a desired route (e.g., wishlist view)
        return redirect()->route('wishlist.view');
    }

    public function deleteItem($itemId)
    {
        // Find the wishlist item
        $wishlistItem = WishlistItem::find($itemId);

        // Check if the item exists and belongs to the current user
        if (!$wishlistItem || $wishlistItem->user_id != auth()->user()->id) {
            return back()->with('error', 'Item not found or access denied.');
        }

        // Delete the item
        $wishlistItem->delete();

        // Redirect to the wishlist view
        return redirect()->route('wishlist.view');
    }

    public function updateItem(Request $request, $itemId)
    {
        // Find the wishlist item
        $wishlistItem = WishlistItem::find($itemId);

        // Check if the item exists and belongs to the current user
        if (!$wishlistItem || $wishlistItem->user_id != auth()->user()->id) {
            return back()->with('error', 'Item not found or access denied.');
        }

        // Validate the request data
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'bought' => 'required|boolean',
        ]);

        // Update the wishlist item
        $wishlistItem->update([
            'title' => $request->title,
            'description' => $request->description,
            'bought' => $request->bought,
        ]);

        // Redirect to the wishlist view
        return redirect()->route('wishlist.view');
    }
}

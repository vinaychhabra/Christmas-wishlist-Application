<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Group;
use App\Models\User;

class GroupController extends Controller
{
    public function createGroup(Request $request)
    {
        // Validate the request data
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        // Create a new group
        $group = Group::create([
            'name' => $request->name,
            'created_by_user_id' => auth()->user()->id,
        ]);

        // Automatically add the creator to the group
        $group->users()->attach(auth()->user()->id);

        // Redirect to a desired route after group creation
        return redirect()->route('group.view', ['id' => $group->id]);
    }

    public function joinGroup(Request $request, $groupId)
    {
        // Find the group by ID
        $group = Group::find($groupId);

        // Check if group exists
        if (!$group) {
            return back()->with('error', 'Group not found.');
        }

        // Add the current user to the group
        $group->users()->attach(auth()->user()->id);

        // Redirect to the group view
        return redirect()->route('group.view', ['id' => $groupId]);
    }

    public function listMembers($groupId)
    {
        // Find the group by ID
        $group = Group::find($groupId);

        // Check if group exists
        if (!$group) {
            return back()->with('error', 'Group not found.');
        }

        // Get all members of the group
        $members = $group->users;

        // Return a view with members data (Assuming you have a view named 'group.members')
        return view('group.members', ['members' => $members]);
    }
	
	// In app/Http/Controllers/GroupController.php

public function showCreateGroupForm()
{
    return view('group.create_group'); // Ensure create_group.blade.php exists in resources/views/group
}

	
}
